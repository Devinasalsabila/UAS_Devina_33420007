package studio.devina.hymartuas

data class ImageData (
    val imageUrl : String
)