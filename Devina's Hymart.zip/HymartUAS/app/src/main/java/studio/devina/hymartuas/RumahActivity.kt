package studio.devina.hymartuas

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class RumahActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rumah)
    }
}